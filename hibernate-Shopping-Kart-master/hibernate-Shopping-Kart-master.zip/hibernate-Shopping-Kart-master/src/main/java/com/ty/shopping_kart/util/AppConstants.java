package com.ty.shopping_kart.util;

public interface AppConstants {
	String SECRETE_KEY = "prashi";
}
